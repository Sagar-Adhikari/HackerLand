﻿using HackerLand;

int n = 3;
int cLib = 2;
int cRoad = 1;
int[,] edges = {{1,2},{3,1},{2,3}};
// int[,] edges = {{1,3},{3,4},{2,4},{1,2},{2,3},{5,6}};
// int[,] edges = {{1,2},{1,3},{2,3},{2,4},{3,4},{5,6},{7,8},{7,9},{8,9},{9,10},{8,10}};
var graph = new Graph(n).Initialize(edges);

int totalCost = 0;

if(cLib < cRoad)
{
  totalCost = n * cLib;
}
else
{
  var islandsAndEdges = graph.GetTotalIslandsAndEdges();
  totalCost = cLib * islandsAndEdges[0] + cRoad * islandsAndEdges[1];
}


Console.WriteLine(graph.ToString());
// Console.WriteLine($"Total Islands: {islandsAndEdges[0]} Total Roads: {islandsAndEdges[1]}");

Console.WriteLine($"Total Cost: {totalCost}.");